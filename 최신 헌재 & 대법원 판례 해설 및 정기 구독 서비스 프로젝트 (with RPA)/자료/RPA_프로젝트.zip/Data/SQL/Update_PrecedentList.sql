CREATE PROCEDURE [dbo].[Update_PrecedentList]
AS
BEGIN
	DELETE APC_PrecedentList_Raw
		FROM APC_PrecedentList_Raw	AS A
		JOIN APC_PrecedentList		AS B ON B.PRSeq = A.PRSeq

	INSERT INTO APC_PrecedentList SELECT * FROM APC_PrecedentList_Raw

	DELETE APC_PrecedentList_Raw
END