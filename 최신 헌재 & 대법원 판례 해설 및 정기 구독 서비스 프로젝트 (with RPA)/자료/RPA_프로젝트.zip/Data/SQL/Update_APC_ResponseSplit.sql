CREATE PROCEDURE [dbo].[UPDATE_APC_ResponseSplit]
	AS
BEGIN
	--기존 plit 작업 중 오류 존재시 ResponseDeserializeError에 데이터를 넣지 않고 LogDateTime만 업데이트(오류 미해결)
	UPDATE ResponseDeserializeError
		SET	LogDateTime = GETDATE()
		FROM ResponseDeserializeError		AS A
		JOIN ResponseDeserializeError_Raw	AS B ON B.PRSeq = A.PRSeq
		
	
	DELETE ResponseDeserializeError_Raw
		FROM ResponseDeserializeError_Raw	AS A
		JOIN ResponseDeserializeError		AS B ON B.PRSeq = A.PRSeq
	


	--기존 Split 작업 중 오류가 발생했던 건이  정상처리된 경우 ResponseDeserializeError에서 목록 삭제
	DELETE ResponseDeserializeError
		FROM ResponseDeserializeError	AS A
		JOIN APC_Summary_Raw				AS B ON B.PRSeq = A.PRSeq
		
	--신규 오류건 INSERT 처리
	INSERT INTO ResponseDeserializeError(PRSeq) SELECT PRSeq FROM ResponseDeserializeError_Raw

	DELETE ResponseDeserializeError_Raw

	
	--APC_Summary
	DELETE APC_Summary_Raw
		FROM APC_Summary_Raw	AS A
		JOIN APC_Summary		AS B ON B.PRSeq = A.PRSeq

	INSERT INTO APC_Summary SELECT * FROM APC_Summary_Raw

	DELETE APC_Summary_Raw

	--APC_LegalTerm
	DELETE APC_LegalTerm_Raw
		FROM APC_LegalTerm_Raw	AS A
		JOIN APC_LegalTerm	AS B ON B.PRSeq = A.PRSeq

	INSERT INTO APC_LegalTerm SELECT * FROM APC_LegalTerm_Raw

	DELETE APC_LegalTerm_Raw

	--APC_Keyword
	DELETE APC_Keyword_Raw
		FROM APC_Keyword_Raw	AS A
		JOIN APC_Keyword		AS B ON B.PRSeq = A.PRSeq

	INSERT INTO APC_Keyword SELECT * FROM APC_Keyword_Raw

	DELETE APC_Keyword_Raw

END