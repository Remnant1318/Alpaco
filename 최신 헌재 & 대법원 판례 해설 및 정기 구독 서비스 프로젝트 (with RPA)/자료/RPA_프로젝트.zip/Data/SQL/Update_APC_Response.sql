CREATE PROCEDURE [dbo].[Update_APC_Response]
AS
BEGIN
	DELETE APC_Response_Raw
		FROM APC_Response		AS A 
		JOIN APC_Response_Raw	AS B ON B.PRSeq = A.PRSeq

	INSERT INTO APC_Response	SELECT * FROM APC_Response_Raw
	
	DELETE APC_Response_Raw
END