CREATE PROCEDURE [dbo].[Update_APC_PRListType]
AS
BEGIN
	DELETE APC_PRListTypeRaw
		FROM APC_PRListTypeRaw	AS A
		JOIN APC_PRListType		AS B ON B.PRSeq = A.PRSeq
								AND B.PRListType = A.PRListType

	INSERT INTO APC_PRListType SELECT * FROM APC_PRListTypeRaw

	DELETE APC_PRListTypeRaw

END