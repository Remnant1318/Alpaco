CREATE PROCEDURE [dbo].[Update_APC_Precedent]
 as 
BEGIN
	DELETE APC_Precedent_RAW
		FROM APC_Precedent_RAW	AS A
		JOIN APC_Precedent		AS B ON B.PRSeq = A.PRSeq

	INSERT INTO APC_Precedent SELECT * FROM APC_Precedent_RAW

	DELETE APC_Precedent_RAW
END