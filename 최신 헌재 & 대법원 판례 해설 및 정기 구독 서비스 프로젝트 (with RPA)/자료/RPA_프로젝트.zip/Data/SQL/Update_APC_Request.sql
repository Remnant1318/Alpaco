CREATE PROCEDURE [dbo].[Update_APC_Request]
AS
BEGIN
	DELETE APC_Request_Raw
		FROM APC_Request		AS A 
		JOIN APC_Request_Raw	AS B ON B.PRSeq = A.PRSeq

	INSERT INTO APC_Request	SELECT * FROM APC_Request_Raw
	
	DELETE APC_Request_Raw
END