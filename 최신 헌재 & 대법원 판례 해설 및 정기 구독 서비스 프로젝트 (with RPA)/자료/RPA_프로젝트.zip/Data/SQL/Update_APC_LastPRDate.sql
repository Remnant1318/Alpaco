CREATE PROCEDURE [dbo].[Update_APC_LastPRDate]
AS
BEGIN
	IF EXISTS(SELECT 1 FROM APC_LastPRDate WHERE PRListType = 'Hot')
	BEGIN
		UPDATE APC_LastPRDate
			SET LastDate = Z.LastDate
			FROM APC_LastPRDate AS A
			JOIN (
				SELECT TOP 1 E.PRListType, CONVERT(DATETIME, REPLACE(PRDate, '.', '')) AS LastDate
					FROM APC_Precedent	AS A
					JOIN APC_PRListType AS E ON E.PRSeq = A.PRSeq
										AND E.PRListType = 'Hot'
					JOIN APC_LastPRDate AS F ON F.PRListType = E.PRListType		
					WHERE CONVERT(DATETIME, REPLACE(PRDate, '.', '')) > F.LastDate
					ORDER BY F.LastDate DESC
				 ) AS Z ON Z.PRListType = A.PRListType
	END
	ELSE
	BEGIN
		INSERT INTO APC_LastPRDate SELECT 'Hot', CONVERT(DATETIME, REPLACE('2023. 01. 01', '.', ''))
	END

	IF EXISTS(SELECT 1 FROM APC_LastPRDate WHERE PRListType = 'New')
	BEGIN
		UPDATE APC_LastPRDate
			SET LastDate = Z.LastDate
			FROM APC_LastPRDate AS A
			JOIN (
				SELECT TOP 1 E.PRListType, CONVERT(DATETIME, REPLACE(PRDate, '.', '')) AS LastDate
					FROM APC_Precedent	AS A
					JOIN APC_PRListType AS E ON E.PRSeq = A.PRSeq
										AND E.PRListType = 'New'
					JOIN APC_LastPRDate AS F ON F.PRListType = E.PRListType		
					WHERE CONVERT(DATETIME, REPLACE(PRDate, '.', '')) > F.LastDate
					ORDER BY F.LastDate DESC
				 ) AS Z ON Z.PRListType = A.PRListType
	END
	ELSE
	BEGIN
		INSERT INTO APC_LastPRDate SELECT 'New', CONVERT(DATETIME, REPLACE('2023. 01. 01', '.', ''))
	END
END